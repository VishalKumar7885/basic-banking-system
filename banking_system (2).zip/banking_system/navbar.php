<!-- navbar --> 
      <!DOCTYPE html>
      <html>
      <head>
        <style type="text/css">

        body{margin-top: 1px;
        }
       
          .btn {
                  border: 3.5px solid black;
                  border-radius: 10px;
                  background-color: #7176b8;
                  background-image: linear-gradient(315deg, #ffff 20%, #cb4154 74%);
                  color: black;
                  font-weight: bold;
                  padding: 14px 28px;
                  font-size: 16px;
                  cursor: pointer;
                  margin: 5px;
                  
                }
            
            .df:hover {
        color: white;
        font-size: 16px;
    background-color: #9dc5c3;
background-image: linear-gradient(315deg, #9dc5c3 0%, #5e5c5c 74%);

}



        </style>
      </head>
      <body>
      
      <nav  class="navbar navbar-expand-md navbar-light bg-light">
      <a class="navbar-brand" href="index.php"><img src="img/bank logo.jpg" width="200" height="100"></a>
      
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="btn df" class="nav-link" href="index.php">Home</a>
              </li>
              
              <li class="nav-item">
                <a class="btn df" class="nav-link" href="aboutme.php">About</a>
              </li>
              <li class="nav-item">
                <a class="btn df" class="nav-link" href="contact.php">Contact</a>
              </li>
          </div>
       </nav>
     </body>
     </html>
