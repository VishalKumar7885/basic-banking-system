<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Softora | Transfer Money</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/table.css">
    <link rel="stylesheet" type="text/css" href="css/navbar.css">

    <style type="text/css">
      button{
        transition: 1.5s;
       
      }
      button:hover{
        color: white;
        background-color: #9dc5c3;
background-image: linear-gradient(315deg, #fff 20%, #a9a9a9 74%);
      }
    </style>
</head>

<body style = "background: url(img/plain.jpg);">
<?php
    include 'config.php';
    $sql = "SELECT * FROM `users`";
    $result = mysqli_query($conn,$sql) or die(mysqli_error($conn));
?>

<?php
  include 'navbar.php';
?>

<div class="container">
        <h2 class="text-center pt-4" style="color: #dcdcdc; text-shadow: 5px 3px 5px #36454f; font-weight: bolder; font-size: 60px;">Transfer Money</h2>
        <br>
            <div class="row">
                <div class="col">
                    <div class="table-responsive-sm">
                    <table class="table table-hover table-sm table-striped table-condensed table-bordered">
                        <thead>
                            <tr>
                            <th scope="col" class="text-center py-2" style="color: #fff;text-decoration: underline; font-size: 20px;">Id</th>
                            <th scope="col" class="text-center py-2" style="color: #fff;text-decoration: underline; font-size: 20px;">Name</th>
                            <th scope="col" class="text-center py-2" style="color: #fff;text-decoration: underline; font-size: 20px;">E-Mail</th>
                            <th scope="col" class="text-center py-2" style="color: #fff;text-decoration: underline; font-size: 20px;">Balance</th>
                            <th scope="col" class="text-center py-2" style="color: #fff;text-decoration: underline; font-size: 20px;">Operation</th>
                            </tr>
                        </thead>
                        <tbody>
                <?php 
                    while($rows=mysqli_fetch_assoc($result)){
                ?>
                    <tr>
                        <td class="py-2" style="color: #fff;"><?php echo $rows['id'] ?></td>
                        <td class="py-2" style="color: #fff;"><?php echo $rows['name']?></td>
                        <td class="py-2" style="color: #fff;"><?php echo $rows['email']?></td>
                        <td class="py-2" style="color: #fff;"><?php echo $rows['balance']?></td>
                        <td><a href="selecteduserdetail.php?id= <?php echo $rows['id'] ;?>"> <button type="button" class="btn">Transact</button></a></td> 
                    </tr>
                <?php
                    }
                ?>
            
                        </tbody>
                    </table>
                    </div>
                </div>
            </div> 
         </div>
         <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script> 
</body>
</html>